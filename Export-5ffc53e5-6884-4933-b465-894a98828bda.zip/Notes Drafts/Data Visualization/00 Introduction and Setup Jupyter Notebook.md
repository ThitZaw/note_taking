# 00 - Introduction and Setup - Jupyter Notebook

[https://hub.gke.mybinder.org/user/bokeh-bokeh-notebooks-vtb1rdyw/notebooks/tutorial/00%20-%20Introduction%20and%20Setup.ipynb](https://hub.gke.mybinder.org/user/bokeh-bokeh-notebooks-vtb1rdyw/notebooks/tutorial/00%20-%20Introduction%20and%20Setup.ipynb)

## You can get a new Binder for this repo by clicking [here](https://mybinder.org/v2/gh/bokeh/bokeh-notebooks/master).

The shareable URL for this repo is: https://mybinder.org/v2/gh/bokeh/bokeh-notebooks/master

### Is this a Binder that you created?

If so, your authentication cookie for this Binder has been deleted or expired. You can launch a new Binder for this repo by clicking [here](https://mybinder.org/v2/gh/bokeh/bokeh-notebooks/master).

### Did someone give you this Binder link?

If so, the link is outdated or incorrect. Recheck the link for typos or ask the person who gave you the link for an updated link. A shareable Binder link should look like https://mybinder.org/v2/gh/bokeh/bokeh-notebooks/master.