# 15 Stunning Data Visualizations (And What You Can Learn From Them)

[https://towardsdatascience.com/15-stunning-data-visualizations-and-what-you-can-learn-from-them-fc5b78f21fb8](https://towardsdatascience.com/15-stunning-data-visualizations-and-what-you-can-learn-from-them-fc5b78f21fb8)

![0*LLDB1u6_otXqg88g.jpg](15%20Stunning%20Data%20Visualizations%20And%20What%20You%20Can%20L/0LLDB1u6_otXqg88g.jpg)

We’re drowning in data. Everyday, . This is the equivalent of 90% of the world’s information–created in the last two years alone. Now this is what we call “big data.”