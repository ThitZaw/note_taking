# Earth science

[Earth Lab: Free, online courses, tutorials and tools](https://www.earthdatascience.org)

[General info - Intro to Python GIS documentation](https://automating-gis-processes.github.io/CSC18/course-info/course-info.html)