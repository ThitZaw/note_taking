# Chapter 5 Machine Learning Basics

Class: deep learning
Created: Jan 05, 2020 5:31 PM
Materials: http://www.deeplearningbook.org/contents/ml.html
Reviewed: No
Type: Study note