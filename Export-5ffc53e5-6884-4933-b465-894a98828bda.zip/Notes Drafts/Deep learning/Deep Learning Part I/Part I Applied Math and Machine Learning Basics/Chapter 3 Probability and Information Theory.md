# Chapter 3
Probability and Information
Theory

Class: deep learning
Created: Jan 05, 2020 5:25 PM
Materials: http://www.deeplearningbook.org/contents/prob.html
Reviewed: No
Type: Study note