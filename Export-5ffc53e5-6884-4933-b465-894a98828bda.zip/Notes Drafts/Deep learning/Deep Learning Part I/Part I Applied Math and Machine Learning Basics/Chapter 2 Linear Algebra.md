# Chapter 2 Linear Algebra

Class: deep learning
Created: Jan 05, 2020 5:19 PM
Materials: http://www.deeplearningbook.org/contents/linear_algebra.html
Reviewed: No
Type: Study note

# 2.1 Scalars, Vectors, Matrices and Tensors

- Scalars
- Vectors