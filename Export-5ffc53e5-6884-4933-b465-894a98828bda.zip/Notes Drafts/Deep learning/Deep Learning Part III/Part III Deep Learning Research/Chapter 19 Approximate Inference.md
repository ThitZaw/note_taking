# Chapter 19 Approximate Inference

Class: deep learning
Created: Jan 05, 2020 5:45 PM
Materials: http://www.deeplearningbook.org/contents/inference.html
Reviewed: No
Type: Study note