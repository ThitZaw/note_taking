# Chapter 20 Deep Generative Models

Class: deep learning
Created: Jan 05, 2020 5:49 PM
Materials: http://www.deeplearningbook.org/contents/generative_models.html
Reviewed: No
Type: Study note