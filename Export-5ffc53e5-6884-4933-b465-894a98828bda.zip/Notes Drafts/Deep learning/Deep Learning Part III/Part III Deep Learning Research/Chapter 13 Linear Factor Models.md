# Chapter 13 Linear Factor Models

Class: deep learning
Created: Jan 05, 2020 5:45 PM
Materials: http://www.deeplearningbook.org/contents/linear_factors.html
Reviewed: No
Type: Study note