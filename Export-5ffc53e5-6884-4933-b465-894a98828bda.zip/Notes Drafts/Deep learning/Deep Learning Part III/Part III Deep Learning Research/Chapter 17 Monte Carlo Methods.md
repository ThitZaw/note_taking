# Chapter 17 Monte Carlo Methods

Class: deep learning
Created: Jan 05, 2020 5:45 PM
Materials: http://www.deeplearningbook.org/contents/monte_carlo.html
Reviewed: No
Type: Study note