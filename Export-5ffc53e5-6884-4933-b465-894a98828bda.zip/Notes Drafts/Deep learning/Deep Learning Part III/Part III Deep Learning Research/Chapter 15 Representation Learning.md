# Chapter 15 Representation Learning

Class: deep learning
Created: Jan 05, 2020 5:45 PM
Materials: http://www.deeplearningbook.org/contents/representation.html
Reviewed: No
Type: Study note