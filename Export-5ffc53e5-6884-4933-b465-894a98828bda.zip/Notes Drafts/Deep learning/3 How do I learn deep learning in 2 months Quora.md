# (3) How do I learn deep learning in 2 months? - Quora

[https://www.quora.com/How-do-I-learn-deep-learning-in-2-months](https://www.quora.com/How-do-I-learn-deep-learning-in-2-months)

Technically, you can’t… see below. But, depending on your definitions, the short answer is: it depends.

Questions like this sometimes depress me because they seem to intend to trivialise the amount of study and research I’ve done. While I’m not an expert in deep learning, I have studied it, and I don’t feel comfortable saying that I have “learned it”… probably Hinton, LeCun and Ng would say they haven’t “learned” deep learning, simply because it’s an ever expanding field of research that, quite frankly, has a lot of depth to be explored.

Forecasting, something I am an expert in, is often trea...