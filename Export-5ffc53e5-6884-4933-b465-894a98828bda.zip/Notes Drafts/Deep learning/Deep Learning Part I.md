# Deep Learning Part I

[Part I: Applied Math and Machine Learning Basics](Deep%20Learning%20Part%20I/Part%20I%20Applied%20Math%20and%20Machine%20Learning%20Basics.csv)