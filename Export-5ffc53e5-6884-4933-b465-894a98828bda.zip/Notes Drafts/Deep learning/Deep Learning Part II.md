# Deep Learning Part II

[Part II: Modern Practical Deep Networks](Deep%20Learning%20Part%20II/Part%20II%20Modern%20Practical%20Deep%20Networks.csv)