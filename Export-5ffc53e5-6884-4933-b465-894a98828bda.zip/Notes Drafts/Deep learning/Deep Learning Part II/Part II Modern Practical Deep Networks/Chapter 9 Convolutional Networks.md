# Chapter 9 Convolutional Networks

Class: deep learning
Created: Jan 05, 2020 5:40 PM
Materials: http://www.deeplearningbook.org/contents/convnets.html
Reviewed: No
Type: Study note