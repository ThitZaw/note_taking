# Chapter 12 Applications

Class: deep learning
Created: Jan 05, 2020 5:41 PM
Materials: http://www.deeplearningbook.org/contents/applications.html
Reviewed: No
Type: Study note