# Chapter 8 Optimization for Training Deep Models

Class: deep learning
Created: Jan 05, 2020 5:37 PM
Materials: http://www.deeplearningbook.org/contents/optimization.html
Reviewed: No
Type: Study note