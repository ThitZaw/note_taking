# Chapter 11 Practical Methodology

Class: deep learning
Created: Jan 05, 2020 5:41 PM
Materials: http://www.deeplearningbook.org/contents/guidelines.html
Reviewed: No
Type: Study note