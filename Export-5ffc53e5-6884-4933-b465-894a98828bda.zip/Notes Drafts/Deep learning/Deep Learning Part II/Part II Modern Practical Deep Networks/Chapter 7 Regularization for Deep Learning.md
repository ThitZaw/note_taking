# Chapter 7 Regularization for Deep Learning

Class: deep learning
Created: Jan 05, 2020 5:37 PM
Materials: http://www.deeplearningbook.org/contents/regularization.html
Reviewed: No
Type: Study note