# Chapter 6 Deep Feedforward Networks

Class: deep learning
Created: Jan 05, 2020 5:37 PM
Materials: http://www.deeplearningbook.org/contents/mlp.html
Reviewed: No
Type: Study note