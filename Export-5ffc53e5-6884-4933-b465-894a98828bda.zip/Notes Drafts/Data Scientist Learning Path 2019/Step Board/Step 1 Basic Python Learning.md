# Step 1 : Basic Python Learning

Status: Completed

## Python Resources to Learn

1. [Basic Python by Corey Schaftr](https://www.youtube.com/playlist?list=PL-osiE80TeTskrapNbzXhwoFUiLCjGgY7)
2. **Books (mandatory)** — [Python for Data Analysis](http://www3.canisius.edu/~yany/python/Python4DataAnalysis.pdf) — This book covers various aspects of Data Science including loading
data to manipulating, processing, cleaning and visualizing data. Must
keep reference guide for Pandas users.