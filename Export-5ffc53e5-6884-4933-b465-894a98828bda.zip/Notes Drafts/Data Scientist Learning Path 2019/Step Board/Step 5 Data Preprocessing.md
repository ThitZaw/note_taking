# Step : 5 Data Preprocessing

Status: Not Started

1. [Data Preprocessing Story](https://medium.com/ml-research-lab/chapter-5-story-behind-data-preprocessing-799c06d8581d)
2. [Data Preprocessing Tutorial by Analytics Vidhya](https://www.analyticsvidhya.com/blog/2016/07/practical-guide-data-preprocessing-python-scikit-learn/)
3. [data Preprocessing](https://www.youtube.com/watch?v=NWp6DFtnqYk&list=PLjCAGuobkaDDFji_7NsgXMqxSPF30LgEw)