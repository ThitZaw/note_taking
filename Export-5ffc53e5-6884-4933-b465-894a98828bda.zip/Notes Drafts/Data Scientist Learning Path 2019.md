# Data Scientist Learning Path 2019

Created By: Thit Zaw
Last Edited: Jan 15, 2020 9:50 AM
Tags: Algorithm, deep learning, machine learning

![https://images.unsplash.com/photo-1513829596324-4bb2800c5efb?ixlib=rb-1.2.1&q=85&fm=jpg&crop=entropy&cs=srgb](https://images.unsplash.com/photo-1513829596324-4bb2800c5efb?ixlib=rb-1.2.1&q=85&fm=jpg&crop=entropy&cs=srgb)

[Data Scientist Learning Path 2019](https://medium.com/ml-research-lab/data-scientist-learning-path-2018-a82e67d49d8e)

### References :

1. [https://www.analyticsvidhya.com/blog/2017/01/the-most-comprehensive-data-science-learning-plan-for-2017](https://www.analyticsvidhya.com/blog/2017/01/the-most-comprehensive-data-science-learning-plan-for-2017/#five-six)/
2. [https://www.analyticsvidhya.com/learning-paths-data-science-business-analytics-business-intelligence-big-data/learning-path-data-science-python/](https://www.analyticsvidhya.com/learning-paths-data-science-business-analytics-business-intelligence-big-data/learning-path-data-science-python/)
3. [https://dzone.com/articles/10-steps-to-become-data-scientist-in-2018](https://dzone.com/articles/10-steps-to-become-data-scientist-in-2018)
4. [https://medium.freecodecamp.org/a-path-for-you-to-learn-analytics-and-data-skills-bd48ccde7325](https://medium.freecodecamp.org/a-path-for-you-to-learn-analytics-and-data-skills-bd48ccde7325)
5. [https://www.quora.com/How-can-I-become-a-data-scientist-1](https://www.quora.com/How-can-I-become-a-data-scientist-1)

[Step Board](Data%20Scientist%20Learning%20Path%202019/Step%20Board.csv)