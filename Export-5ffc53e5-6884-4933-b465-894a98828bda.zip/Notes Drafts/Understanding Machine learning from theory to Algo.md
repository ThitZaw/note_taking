# Understanding Machine learning from theory to Algorithm

Created By: Thit Zaw
Last Edited: Jan 21, 2020 9:35 AM
Tags: deep learning

![Understanding%20Machine%20learning%20from%20theory%20to%20Algo/index.jpg](Understanding%20Machine%20learning%20from%20theory%20to%20Algo/index.jpg)

[understanding-machine-learning-theory-algorithms.pdf](https://drive.google.com/file/d/1BiT7Uy-jaNOmCtXJ3oLykoefn5xieryt/view?usp=drivesdk)