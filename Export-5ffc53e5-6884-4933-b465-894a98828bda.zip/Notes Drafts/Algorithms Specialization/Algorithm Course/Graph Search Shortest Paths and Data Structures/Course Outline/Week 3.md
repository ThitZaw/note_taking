# Week 3

Description: Heaps; balanced binary search trees.
Tags: Not Started