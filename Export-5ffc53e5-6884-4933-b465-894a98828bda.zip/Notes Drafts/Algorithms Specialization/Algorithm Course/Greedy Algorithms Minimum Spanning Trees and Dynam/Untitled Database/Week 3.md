# Week 3

Description: Huffman codes; introduction to dynamic programming.
Tags: Not Started