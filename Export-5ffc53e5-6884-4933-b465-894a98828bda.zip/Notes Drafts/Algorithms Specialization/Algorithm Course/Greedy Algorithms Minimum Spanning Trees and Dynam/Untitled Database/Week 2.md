# Week 2

Description: Kruskal's MST algorithm and applications to clustering; advanced union-find (optional).
Tags: Not Started