# Week 1

Description: Two motivating applications; selected review; introduction to greedy algorithms; a scheduling application; Prim's MST algorithm.
Tags: Not Started