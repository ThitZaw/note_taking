# Week 4

Description: Advanced dynamic programming: the knapsack problem, sequence alignment, and optimal binary search trees.
Tags: Not Started