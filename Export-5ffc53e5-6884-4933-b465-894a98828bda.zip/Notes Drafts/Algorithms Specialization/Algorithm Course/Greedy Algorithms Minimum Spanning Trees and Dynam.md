# Greedy Algorithms, Minimum Spanning Trees, and Dynamic Programming

Course No: 3
Created: Jan 05, 2020 11:23 PM
Description: The primary topics in this part of the specialization are: greedy algorithms (scheduling, minimum spanning trees, clustering, Huffman codes) and dynamic programming (knapsack, sequence alignment, optimal search trees).
Tags: Open

[Untitled](Greedy%20Algorithms%20Minimum%20Spanning%20Trees%20and%20Dynam/Untitled%20Database.csv)