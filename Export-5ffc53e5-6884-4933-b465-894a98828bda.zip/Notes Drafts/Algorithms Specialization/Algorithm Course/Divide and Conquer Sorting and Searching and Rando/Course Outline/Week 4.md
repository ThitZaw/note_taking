# Week 4

Description: Linear-time selection; graphs, cuts, and the contraction algorithm.
Status: Not Started

Week 4 Lecture slides:

- 8: Linear-time Selection
    - [Randomized Selection](https://github.com/SSQ/Coursera-Stanford-Divide-and-Conquer-Sorting-and-Searching-and-Randomized-Algorithms/blob/master/Lecture%20Slides/8.1-slides_algo-select-ralgorithm_typed.pdf)
    - [Deterministic Selection](https://github.com/SSQ/Coursera-Stanford-Divide-and-Conquer-Sorting-and-Searching-and-Randomized-Algorithms/blob/master/Lecture%20Slides/8.3-slides_algo-select-dalgorithm_typed.pdf)
- 9: Graphs and The Minimum Cut
    - [Random Contraction Algorithm](https://github.com/SSQ/Coursera-Stanford-Divide-and-Conquer-Sorting-and-Searching-and-Randomized-Algorithms/blob/master/Lecture%20Slides/9.3-slides_algo-karger-algorithm_typed.pdf)