# Why Study Algorithms?

Lecturer Slide: https://github.com/SSQ/Coursera-Stanford-Divide-and-Conquer-Sorting-and-Searching-and-Randomized-Algorithms/blob/master/Lecture%20Slides/1.1-algo1-intro1.pdf
Status: Completed
Video Link: https://www.youtube.com/watch?v=yRM3sc57q0c&t=5s