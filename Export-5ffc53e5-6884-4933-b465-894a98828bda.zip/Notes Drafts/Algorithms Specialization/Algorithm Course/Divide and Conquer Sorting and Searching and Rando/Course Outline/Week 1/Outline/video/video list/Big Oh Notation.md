# Big-Oh Notation

Lecturer Slide: https://github.com/SSQ/Coursera-Stanford-Divide-and-Conquer-Sorting-and-Searching-and-Randomized-Algorithms/blob/master/Lecture%20Slides/2.2-slides_algo-asymptotic1_typed.pdf
Status: Completed
Video Link: https://youtu.be/QfRSeibcugw

[What is a plain English explanation of "Big O" notation?](https://stackoverflow.com/questions/487258/what-is-a-plain-english-explanation-of-big-o-notation)