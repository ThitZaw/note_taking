# Merge Sort: Pseudocode

Lecturer Slide: https://github.com/SSQ/Coursera-Stanford-Divide-and-Conquer-Sorting-and-Searching-and-Randomized-Algorithms/blob/master/Lecture%20Slides/1.6-slides_algo-merge2_typed.pdf
Status: Completed
Video Link: https://www.youtube.com/watch?v=rBd5w0rQaFo