# Merge Sort: Analysis

Lecturer Slide: https://github.com/SSQ/Coursera-Stanford-Divide-and-Conquer-Sorting-and-Searching-and-Randomized-Algorithms/blob/master/Lecture%20Slides/1.7-slides_algo-merge3_typed.pdf
Status: Completed
Video Link: https://youtu.be/8ArtRiTkYEw