# Merge Sort: Motivation and Example

Lecturer Slide: https://github.com/SSQ/Coursera-Stanford-Divide-and-Conquer-Sorting-and-Searching-and-Randomized-Algorithms/blob/master/Lecture%20Slides/1.5-slides_algo-merge1_typed.pdf
Status: Completed
Video Link: https://www.youtube.com/watch?v=kiyRJ7GVWro&t=372s