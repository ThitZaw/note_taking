# Integer Multiplication

Lecturer Slide: https://github.com/SSQ/Coursera-Stanford-Divide-and-Conquer-Sorting-and-Searching-and-Randomized-Algorithms/blob/master/Lecture%20Slides/1.2-algo1-intro2_typed.pdf
Status: Completed
Video Link: https://www.youtube.com/watch?v=6u0Vaj4nn54&t=5s