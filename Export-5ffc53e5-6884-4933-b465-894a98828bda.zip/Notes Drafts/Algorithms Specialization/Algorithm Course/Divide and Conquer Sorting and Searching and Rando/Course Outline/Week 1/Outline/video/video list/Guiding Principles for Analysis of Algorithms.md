# Guiding Principles for Analysis of Algorithms

Lecturer Slide: https://github.com/SSQ/Coursera-Stanford-Divide-and-Conquer-Sorting-and-Searching-and-Randomized-Algorithms/blob/master/Lecture%20Slides/1.8-slides_algo-guiding_typed.pdf
Status: Completed
Video Link: https://youtu.be/-yP11jqilwM