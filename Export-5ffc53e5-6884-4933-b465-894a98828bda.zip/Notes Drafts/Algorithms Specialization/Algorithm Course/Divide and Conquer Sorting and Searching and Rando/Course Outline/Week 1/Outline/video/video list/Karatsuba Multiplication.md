# Karatsuba Multiplication

Lecturer Slide: https://github.com/SSQ/Coursera-Stanford-Divide-and-Conquer-Sorting-and-Searching-and-Randomized-Algorithms/blob/master/Lecture%20Slides/1.3-algo1-intro3_typed.pdf
Status: Completed
Video Link: https://www.youtube.com/watch?v=JCbZayFr9RE&t=1s