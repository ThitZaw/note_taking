# Week 4

Description: Local search algorithms for NP-complete problems; the wider world of algorithms.
Status: Not Started