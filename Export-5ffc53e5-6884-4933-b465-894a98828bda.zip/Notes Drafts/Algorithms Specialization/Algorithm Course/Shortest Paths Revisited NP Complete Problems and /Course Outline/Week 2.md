# Week 2

Description: NP-complete problems and exact algorithms for them.
Status: Not Started