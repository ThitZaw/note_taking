# Week 3

Description: Approximation algorithms for NP-complete problems.
Status: Not Started