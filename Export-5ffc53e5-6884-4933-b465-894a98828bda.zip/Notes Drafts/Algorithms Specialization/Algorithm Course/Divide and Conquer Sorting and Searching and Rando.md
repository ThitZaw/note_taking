# Divide and Conquer, Sorting and Searching, and Randomized Algorithms

Course No: 1
Created: Jan 05, 2020 11:23 PM
Description: The primary topics in this part of the specialization are: asymptotic ("Big-oh") notation, sorting and searching, divide and conquer (master method, integer and matrix multiplication, closest pair), and randomized algorithms (QuickSort, contraction algorithm for min cuts).
Tags: In Progress

[Course Outline](Divide%20and%20Conquer%20Sorting%20and%20Searching%20and%20Rando/Course%20Outline.csv)

[SSQ/Coursera-Stanford-Divide-and-Conquer-Sorting-and-Searching-and-Randomized-Algorithms](https://github.com/SSQ/Coursera-Stanford-Divide-and-Conquer-Sorting-and-Searching-and-Randomized-Algorithms/tree/master/Lecture%20Slides)