# (11) Which one is the best deep learning course, Fast.ai, Andrew Ng, Google ML crash course, or others? - Quora

Created By: Thit Zaw
Last Edited: Jan 25, 2020 10:51 PM
URL: https://www.quora.com/Which-one-is-the-best-deep-learning-course-Fast-ai-Andrew-Ng-Google-ML-crash-course-or-others

Unfortunately, the answer is ALL.

Andrew’s course is a great theoretical course and covers all important topics which is relevant for a ML engineer. It lays great foundation for studing futher about machine learning.

But it is not complete by itself in any way. The course selected Matlab as a choice of language. Nobody codes production ML models in matlab or octave ! ( :) ) so you would need to do Google ML . Warning - GML is tied to a vendor and hence you would learn a bit of vendor specific things like CMLE.

[fast.ai](http://fast.ai/) course on the topic is a course which involves more work. The assignments an...