# research paper

Created By: Thit Zaw
Last Edited: Feb 20, 2020 7:57 AM

Research Papers 📃📄 တွေ Thesis📓📔📒📚 တွေ ဘယ်မှာရှာမလဲ???
အောက်ပါ link တွေမှာ ရှာဖွေ download ဆွဲနိုင်ပါသည်။

1. Google Scholar
[https://scholar.google.com](https://scholar.google.com/)
2. ERIC
[https://eric.ed.gov](https://eric.ed.gov/)
3. [Academeia.edu](http://academeia.edu/)[https://www.academia.edu](https://www.academia.edu/)
4. Microsoft Academic Search
[http://academic.research.microsoft.com](http://academic.research.microsoft.com/)
5. Science Direct
[http://www.sciencedirect.com](http://www.sciencedirect.com/)
6. JSTOR
[http://www.jstor.org](http://www.jstor.org/)
7. Mendeley
[https://www.mendeley.com](https://www.mendeley.com/)
8. Questia
[https://www.questia.com](https://www.questia.com/)
9. WorldCat
[http://www.worldcat.org](http://www.worldcat.org/)
10. IngentaConnect
[http://www.ingentaconnect.com](http://www.ingentaconnect.com/)
11. AgriCola
[https://agricola.nal.usda.gov](https://agricola.nal.usda.gov/)
12. Journal TOCs
[http://www.journaltocs.hw.ac.uk](http://www.journaltocs.hw.ac.uk/)
13. [Academicjournals.org](http://academicjournals.org/)[http://www.academicjournals.org](http://www.academicjournals.org/)
14. Journal Seek
[http://journalseek.net](http://journalseek.net/)
15. WorldWideScience
[https://worldwidescience.org](https://worldwidescience.org/)
16.The National Bureau of Economic Research
[www.nber.org/papers](http://www.nber.org/papers)
16. Research Gate
[https://www.researchgate.net/](https://www.researchgate.net/)

Original Copy
Source : MES
အားလုံး ပညာခရီးလမ်းဖြောင့်ဖြူးကြပါစေ