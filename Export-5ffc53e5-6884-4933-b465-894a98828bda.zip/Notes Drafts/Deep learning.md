# Deep learning

Created By: Thit Zaw
Last Edited: Feb 29, 2020 10:44 AM
Tags: deep learning

[Deep Learning Part I](Deep%20learning/Deep%20Learning%20Part%20I.md)

[Deep Learning Part II](Deep%20learning/Deep%20Learning%20Part%20II.md)

[Deep Learning Part III](Deep%20learning/Deep%20Learning%20Part%20III.md)

![https://images.unsplash.com/photo-1514880448122-7e417213b996?ixlib=rb-1.2.1&q=85&fm=jpg&crop=entropy&cs=srgb](https://images.unsplash.com/photo-1514880448122-7e417213b996?ixlib=rb-1.2.1&q=85&fm=jpg&crop=entropy&cs=srgb)

[MIT Deep Learning 6.S191](http://introtodeeplearning.com/)

[(3) How do I learn deep learning in 2 months? - Quora](Deep%20learning/3%20How%20do%20I%20learn%20deep%20learning%20in%202%20months%20Quora.md)