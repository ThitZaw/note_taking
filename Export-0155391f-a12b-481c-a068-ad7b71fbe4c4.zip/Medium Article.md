# Medium Article

Created By: Thit Zaw
Last Edited: Apr 05, 2020 10:56 PM

[https://towardsdatascience.com/you-can-now-speak-using-someone-elses-voice-with-deep-learning-8be24368fa2b](https://towardsdatascience.com/you-can-now-speak-using-someone-elses-voice-with-deep-learning-8be24368fa2b)

[https://medium.com/@Francesco_AI/the-psychology-of-data-science-3f3a72bc1b72](https://medium.com/@Francesco_AI/the-psychology-of-data-science-3f3a72bc1b72)

[https://www.vinta.com.br/blog/2018/django-rest-framework-read-write-serializers/](https://www.vinta.com.br/blog/2018/django-rest-framework-read-write-serializers/)

[https://www.freecodecamp.org/news/how-to-write-an-amazing-cover-letter-that-will-get-you-hired/](https://www.freecodecamp.org/news/how-to-write-an-amazing-cover-letter-that-will-get-you-hired/)

[https://stackoverflow.com/questions/487258/what-is-a-plain-english-explanation-of-big-o-notation/487278#487278](https://stackoverflow.com/questions/487258/what-is-a-plain-english-explanation-of-big-o-notation/487278#487278)

[https://towardsdatascience.com/intro-to-deep-learning-c025efd92535](https://towardsdatascience.com/intro-to-deep-learning-c025efd92535)

[https://towardsdatascience.com/making-3-easy-maps-with-python-fb7dfb1036](https://towardsdatascience.com/making-3-easy-maps-with-python-fb7dfb1036)

[https://medium.com/@saidakbarp/interactive-map-visualization-with-folium-in-python-2e95544d8d9b](https://medium.com/@saidakbarp/interactive-map-visualization-with-folium-in-python-2e95544d8d9b)

[https://medium.com/nightingale/is-your-data-story-actually-a-story-3d1fa52394d9](https://medium.com/nightingale/is-your-data-story-actually-a-story-3d1fa52394d9)

[https://towardsdatascience.com/top-10-map-types-in-data-visualization-b3a80898ea70](https://towardsdatascience.com/top-10-map-types-in-data-visualization-b3a80898ea70)

[https://towardsdatascience.com/analyzing-my-google-location-history-d3a5c56c7b70](https://towardsdatascience.com/analyzing-my-google-location-history-d3a5c56c7b70)

[https://towardsdatascience.com/create-a-heat-map-from-your-google-location-history-in-3-easy-steps-e66c93925914](https://towardsdatascience.com/create-a-heat-map-from-your-google-location-history-in-3-easy-steps-e66c93925914)

[https://medium.com/visumd/creating-interactive-visualizations-should-be-easier-137212ef1fb1](https://medium.com/visumd/creating-interactive-visualizations-should-be-easier-137212ef1fb1)

[https://medium.com/vis-gl/introducing-kepler-gl-for-jupyter-f72d41659fbf](https://medium.com/vis-gl/introducing-kepler-gl-for-jupyter-f72d41659fbf)

[https://towardsdatascience.com/data-curious-2017-year-in-review-my-favourite-data-stories-datasets-and-visualisations-from-last-4214bf634f56](https://towardsdatascience.com/data-curious-2017-year-in-review-my-favourite-data-stories-datasets-and-visualisations-from-last-4214bf634f56)

[https://towardsdatascience.com/spatial-data-geopandas-and-pokémon-part-i-8525c801ed18](https://towardsdatascience.com/spatial-data-geopandas-and-pok%C3%A9mon-part-i-8525c801ed18)

[https://towardsdatascience.com/https-medium-com-vishalmorde-xgboost-algorithm-long-she-may-rein-edd9f99be63d](https://towardsdatascience.com/https-medium-com-vishalmorde-xgboost-algorithm-long-she-may-rein-edd9f99be63d)

[https://medium.com/nightingale/six-hats-of-data-visualization-82d73af1a765](https://medium.com/nightingale/six-hats-of-data-visualization-82d73af1a765)

[https://towardsdatascience.com/location-location-location-in-data-science-fa9ebc046c95](https://towardsdatascience.com/location-location-location-in-data-science-fa9ebc046c95)

[https://medium.com/better-programming/how-to-convert-latitude-longitude-to-distance-utm-and-geojson-34c982cda40](https://medium.com/better-programming/how-to-convert-latitude-longitude-to-distance-utm-and-geojson-34c982cda40)

[https://medium.com/better-programming/9-popular-github-repos-for-every-web-developer-6826582291bc](https://medium.com/better-programming/9-popular-github-repos-for-every-web-developer-6826582291bc)

[https://medium.com/@bartomolina/geospatial-data-visualization-in-jupyter-notebooks-ffa79e4ba7f8](https://medium.com/@bartomolina/geospatial-data-visualization-in-jupyter-notebooks-ffa79e4ba7f8)

[https://towardsdatascience.com/everything-you-need-to-know-about-web-scraping-6541b241f27](https://towardsdatascience.com/everything-you-need-to-know-about-web-scraping-6541b241f27e)

[https://medium.com/runscope/openapi-swagger-resource-list-for-api-developers-9f6d769d9c9d](https://medium.com/runscope/openapi-swagger-resource-list-for-api-developers-9f6d769d9c9d)

[An overview of every Data Visualization course on the internet](https://www.notion.so/An-overview-of-every-Data-Visualization-course-on-the-internet-9e426dff80b946419250eed3046cc2fc)

[4 More Quick and Easy Data Visualizations in Python with Code](https://www.notion.so/4-More-Quick-and-Easy-Data-Visualizations-in-Python-with-Code-e18f1d01f93a43c8ae3158bfd2931013)

[Introducing Semiotic for Data Visualization - Elijah Meeks - Medium](https://www.notion.so/Introducing-Semiotic-for-Data-Visualization-Elijah-Meeks-Medium-39eea85a01744eff83b84e8293162321)

[https://medium.com/javascript-in-plain-english/what-should-i-build-for-my-first-reactjs-project-4c575d04728](https://medium.com/javascript-in-plain-english/what-should-i-build-for-my-first-reactjs-project-4c575d04728)

[https://medium.com/better-programming/heres-a-list-of-app-ideas-you-could-start-coding-today-b5f33f94a42e](https://medium.com/better-programming/heres-a-list-of-app-ideas-you-could-start-coding-today-b5f33f94a42e)

[https://towardsdatascience.com/11-best-data-science-classes-if-youre-locked-home-because-of-coronavirus-ca7d2d74a454](https://towardsdatascience.com/11-best-data-science-classes-if-youre-locked-home-because-of-coronavirus-ca7d2d74a454)

[https://medium.com/mind-cafe/the-7-habits-of-highly-ineffective-people-44b0ff317be](https://medium.com/mind-cafe/the-7-habits-of-highly-ineffective-people-44b0ff317be)

[https://medium.com/better-programming/how-to-make-extra-money-as-a-programmer-144d76b76ffd](https://medium.com/better-programming/how-to-make-extra-money-as-a-programmer-144d76b76ffd)